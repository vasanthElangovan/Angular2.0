import { Injectable } from '@angular/core';

@Injectable()
export class UtilityServiceService {

    constructor() {

    }

    Capital(item: string):string {
        return item[0].toUpperCase() + item.substring(1);
    }
}
