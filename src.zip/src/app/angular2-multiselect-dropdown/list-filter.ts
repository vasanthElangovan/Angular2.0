import { Pipe, PipeTransform } from '@angular/core';

import { ListItem } from './multiselect.model';

@Pipe({
    name: 'listFilter',
    pure: false
})
export class ListFilterPipe implements PipeTransform {
    transform(items: any, filter: any): Array<string> {
        if (!items || !filter) {
            return items;
        }
        return items.filter((item: string) => this.applyFilter(item, filter));
    }
    applyFilter(item: string, filter: string): boolean {
        return !(filter && item && item.toLowerCase().indexOf(filter.toLowerCase()) === -1);
    }
}