/// <reference path="angular2-multiselect-dropdown/angular2-multiselect-dropdown.ts" />
import { BrowserModule } from '@angular/platform-browser';
import { NgModule} from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { AppComponent } from './app.component';
import {UtilityServiceService} from './services/utility-service.service';
import { AngularMultiSelectModule } from './angular2-multiselect-dropdown/angular2-multiselect-dropdown';

@NgModule({
    declarations: [
        AppComponent
        
    ],
    imports: [
        BrowserModule,
        FormsModule,
        HttpModule,
        AngularMultiSelectModule
        
    ],
    providers: [UtilityServiceService],
    bootstrap: [AppComponent]
})
export class AppModule { }
