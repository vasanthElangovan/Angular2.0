import { Component, OnInit, NgModule, SimpleChanges, OnChanges, ViewEncapsulation, ContentChild, forwardRef, Input, Output, EventEmitter, ElementRef, AfterViewInit, Pipe, PipeTransform } from '@angular/core';
import { FormsModule, NG_VALUE_ACCESSOR, ControlValueAccessor, NG_VALIDATORS, Validator, FormControl } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { ListItem, MyException } from './multiselect.model';
import { DropdownSettings } from './multiselect.interface';
import { ClickOutsideDirective } from './clickOutside';
import { ListFilterPipe } from './list-filter';
import { Item, TemplateRenderer } from './menu-item';

export const DROPDOWN_CONTROL_VALUE_ACCESSOR: any = {
    provide: NG_VALUE_ACCESSOR,
    useExisting: forwardRef(() => AngularMultiSelect),
    multi: true
};
export const DROPDOWN_CONTROL_VALIDATION: any = {
    provide: NG_VALIDATORS,
    useExisting: forwardRef(() => AngularMultiSelect),
    multi: true,
}
const noop = () => {
};

@Component({
    selector: 'angular2-multiselect',
    templateUrl: './multiselect.component.html',
    host: { '[class]': 'defaultSettings.classes' },
    styleUrls: ['./multiselect.component.scss'],
    providers: [DROPDOWN_CONTROL_VALUE_ACCESSOR, DROPDOWN_CONTROL_VALIDATION]
})

export class AngularMultiSelect implements OnInit, ControlValueAccessor, OnChanges, Validator {

    @Input()
    data: any;

    @Input()
    settings: DropdownSettings;

    @Output('onSelect')
    onSelect: EventEmitter<string> = new EventEmitter<string>();

    @Output('onDeSelect')
    onDeSelect: EventEmitter<string> = new EventEmitter<string>();

    @Output('onSelectAll')
    onSelectAll: EventEmitter<Array<string>> = new EventEmitter<Array<string>>();

    @Output('onDeSelectAll')
    onDeSelectAll: EventEmitter<Array<string>> = new EventEmitter<Array<string>>();

    @ContentChild(Item) itemTempl: Item;

    public selectedItems: any;
    public isActive: boolean = false;
    public isSelectAll: boolean = false;
    public groupedData: Array<string>;
    filter: string = "";
    defaultSettings: DropdownSettings = {
        singleSelection: false,
        text: 'Select',
        enableCheckAll: true,
        selectAllText: 'Select All',
        unSelectAllText: 'UnSelect All',
        enableSearchFilter: false,
        maxHeight: 300,
        badgeShowLimit: 999999999999,
        classes: '',
        disabled: false,
        searchPlaceholderText: 'Search',
        showCheckbox: true
    }
    public parseError: boolean;
    constructor() {

    }
    ngOnInit() {
        //console.log(this.settings);
        this.settings = Object.assign(this.defaultSettings, this.settings);
        if (this.settings.groupBy) {

            this.groupedData = this.transformData(this.data, this.settings.groupBy);
        }
    }
    ngOnChanges(changes: any) {
        if (changes.data && !changes.data.firstChange) {
            if (this.settings.groupBy) {
                this.groupedData = this.transformData(this.data, this.settings.groupBy);
                if (this.data.length == 0) {
                    this.selectedItems = this.typeof(this.selectedItems) == 'Array' ? [] : this.ClearObject(this.selectedItems);
                }
            }
        }
    }
    ngDoCheck() {
        if (this.selectedItems) {
            if (this.typeof(this.selectedItems) == 'object') {

                if (this.TransformObject2Array(this.selectedItems).length == 0 || this.TransformObject2Array(this.data).length == 0 || this.TransformObject2Array(this.selectedItems).length < this.TransformObject2Array(this.data).length) {
                    this.isSelectAll = false;
                }
            }
            else {
                if (this.selectedItems.length == 0 || this.data.length == 0 || this.selectedItems.length < this.data.length) {
                    this.isSelectAll = false;
                }
            }
        }
    }
    onItemClick(item: string, index: number, evt: any) {

        if (this.settings.disabled) {
            return false;
        }
        let parentnode = evt.currentTarget.parentElement.id
        let found = this.isSelected(item);
        let limit = this.TransformObject2Array(this.selectedItems).length < this.settings.limitSelection ? true : false;

        if (!found) {
            if (this.settings.limitSelection) {
                if (limit) {
                    if (parentnode) this.addSelected(item, parentnode); this.addSelected(item);
                    this.onSelect.emit(item);
                }
            }
            else {
                if (parentnode) this.addSelected(item, parentnode); this.addSelected(item);
                this.onSelect.emit(item);
            }

        }
        else {
            this.removeSelected(item, parentnode);
            this.onDeSelect.emit(item);
        }
        if (this.isSelectAll || this.TransformObject2Array(this.data).length > this.TransformObject2Array(this.selectedItems).length) {
            this.isSelectAll = false;
        }
        if (this.TransformObject2Array(this.data).length == this.TransformObject2Array(this.selectedItems).length) {
            this.isSelectAll = true;
        }
        event.stopPropagation();
    }
    public validate(c: FormControl) {

        return (!this.parseError) ? null : {
            jsonParseError: {
                valid: false,
            },
        };
    }
    private onTouchedCallback: (_: any) => void = noop;
    private onChangeCallback: (_: any) => void = noop;

    writeValue(value: any) {
        if (value !== undefined && value !== null) {
            if (this.settings.singleSelection) {
                try {

                    if (value.length > 1) {
                        this.selectedItems = [value[0]];
                        throw new MyException(404, { "msg": "Single Selection Mode, Selected Items cannot have more than one item." });
                    }
                    else {
                        this.selectedItems = value;
                    }
                }
                catch (e) {
                    console.error(e.body.msg);
                }

            }
            else {
                if (this.settings.limitSelection) {
                    this.selectedItems = value.splice(0, this.settings.limitSelection);
                }
                else {
                    this.selectedItems = value;
                }

                if (this.selectedItems.length === ((this.typeof(value) == "Array") ? this.data.length : this.TransformObject2Array(this.data).length) && ((this.typeof(value) == "Array") ? this.data.length : this.TransformObject2Array(this.data).length) > 0) {
                    this.isSelectAll = true;
                }
                //this.TransformObject2Array(this.data);
            }
        } else {
            this.selectedItems = this.ClearObject(this.selectedItems);
        }
    }

    //From ControlValueAccessor interface
    registerOnChange(fn: any) {
        this.onChangeCallback = fn;
    }

    //From ControlValueAccessor interface
    registerOnTouched(fn: any) {
        this.onTouchedCallback = fn;
    }
    trackByFn(index: number, item: ListItem) {
        return item.id;
    }
    isSelected(clickedItem: any) {
        let found = false;
        if (this.typeof(this.data) == "String") {
            this.selectedItems && this.selectedItems.forEach(item => {
                if (clickedItem === item) {
                    found = true;
                }
            })
        } else {
            if (this.TransformObject2Array(this.selectedItems).indexOf(clickedItem) >= 0) found = true;

        };
        return found;
    }
    addSelected(item: string, parent?: string) {
        if (this.settings.singleSelection) {
            this.selectedItems = this.typeof(this.selectedItems) == 'Array' ? [] : this.ClearObject(this.selectedItems);
            if (parent) this.selectedItems[parent].push(item); else this.selectedItems.push(item);
        }
        else {
            if (parent) {
                this.selectedItems[parent].push(item);
                if (this.TransformObject2Array(this.selectedItems).length > 0) {
                    this.parseError = false;
                }

                else {

                    this.selectedItems.push(item);
                    if (this.selectedItems.length > 0) {
                        this.parseError = false;
                    }
                };

            }
        }
        this.onChangeCallback(this.selectedItems);

    }
    removeSelected(clickedItem: string, parent?: string) {
        if (parent) {
            this.selectedItems[parent] && this.selectedItems[parent].forEach(item => {
                if (clickedItem === item) {
                    this.selectedItems[parent].splice(this.selectedItems[parent].indexOf(item), 1);
                }
            });
        }
        else {
            this.selectedItems && this.selectedItems.forEach(item => {
                if (clickedItem === item) {
                    this.selectedItems.splice(this.selectedItems.indexOf(item), 1);
                }
            });

        }
        if (this.TransformObject2Array(this.selectedItems).length == 0) {
            this.parseError = true;
        }
        this.onChangeCallback(this.selectedItems);
    }
    toggleDropdown(evt: any) {
        if (this.settings.disabled) {
            return false;
        }
        this.isActive = !this.isActive;
        this.filter = "";
        evt.preventDefault();
    }
    closeDropdown() {
        this.filter = "";
        this.isActive = false;
    }
    toggleSelectAll() {
        if (!this.isSelectAll) {
            this.selectedItems = this.typeof(this.selectedItems) == 'Array' ? [] : this.ClearObject(this.selectedItems);
            this.selectedItems = (this.typeof(this.data) == "Array") ? this.data.slice() : this.data;
            this.isSelectAll = true;
            this.onChangeCallback(this.selectedItems);
            this.onSelectAll.emit(this.selectedItems);
        }
        else {
            this.selectedItems = this.typeof(this.selectedItems) == 'Array' ? [] : this.ClearObject(this.selectedItems);
            this.isSelectAll = false;
            this.onChangeCallback(this.selectedItems);
            this.onDeSelectAll.emit(this.selectedItems);
        }
    }
    transformData(arr: Array<string>, field: any): Array<string> {
        const groupedObj: any = arr.reduce((prev: any, cur: any) => {
            if (!prev[cur[field]]) {
                prev[cur[field]] = [cur];
            } else {
                prev[cur[field]].push(cur);
            }
            return prev;
        }, {});
        const tempArr: any = [];
        Object.keys(groupedObj).map(function (x) {
            tempArr.push(groupedObj[x]);
        });
        return tempArr;
    }
    typeof(object: any) {
        return object.constructor.name;
    }

    TransformObject2Array(object: any): Array<string> {
        if (this.typeof(object) == 'Array') return object;
        var result = [];
        try {
            for (var key in object) {
                object[key].map(i => result.push(i));
            };
            return result;
        }
        catch (ex) {
            return result;
        }
    }
    Readkeys(object: any) {
        return Object.keys(object);
    }
    ClearObject(object: any) {
        var result = {};
        try {
            for (var key in object) {
                result[key] = new Array();
            };
            return result;
        }
        catch (ex) {
            return result;
        }
    }
}

@NgModule({
    imports: [CommonModule, FormsModule],
    declarations: [AngularMultiSelect, ClickOutsideDirective, ListFilterPipe, Item, TemplateRenderer],
    exports: [AngularMultiSelect, ClickOutsideDirective, ListFilterPipe, Item, TemplateRenderer]
})
export class AngularMultiSelectModule { }
